package com.example.colorpicker;

public interface OnColorUpdateListener {
    void onColorUpdated(int red, int green, int blue);
}
