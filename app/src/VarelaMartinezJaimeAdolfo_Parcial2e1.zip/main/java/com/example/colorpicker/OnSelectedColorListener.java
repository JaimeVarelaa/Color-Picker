package com.example.colorpicker;

public interface OnSelectedColorListener {
    void onSelectedColor(int red, int green, int blue);
}
