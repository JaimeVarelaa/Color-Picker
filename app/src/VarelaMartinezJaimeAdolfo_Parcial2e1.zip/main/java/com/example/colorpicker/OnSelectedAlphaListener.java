package com.example.colorpicker;

public interface OnSelectedAlphaListener {
    void onselectedAlpha(int alpha);
}
